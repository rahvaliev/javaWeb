package com.ex.examTR;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamTrApplicationTests {

	@Test
	void contextLoads() {
	}

}
