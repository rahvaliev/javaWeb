package com.ex.examTR;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamTrApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamTrApplication.class, args);
	}

}
