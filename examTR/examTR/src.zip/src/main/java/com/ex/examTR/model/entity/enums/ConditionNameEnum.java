package com.ex.examTR.model.entity.enums;

public enum ConditionNameEnum {
    EXCELLENT, GOOD, ACCEPTABLE
}
